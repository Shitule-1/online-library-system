export const Data=[
    {
      "id": 201,
      "name": "The Lost Kingdom",
      "author": "Amy White",
      "category": "fiction",
      "image_url": "https://example.com/fiction1.jpg",
      "year_published": 2021,
      "pages": 350,
      "description": "A fantasy novel set in a forgotten world of magic and intrigue."
    },
    {
      "id": 202,
      "name": "The Power of Habit",
      "author": "Charles Duhigg",
      "category": "nonFiction",
      "image_url": "https://example.com/nonfiction1.jpg",
      "year_published": 2012,
      "pages": 370,
      "description": "An insightful exploration of the science behind habit formation."
    },
    {
      "id": 203,
      "name": "The Adventures of Sammy the Squirrel",
      "author": "Linda Green",
      "category": "childrensBbooks",
      "image_url": "https://example.com/children1.jpg",
      "year_published": 2019,
      "pages": 50,
      "description": "A fun and adventurous story about a squirrel discovering the forest."
    },
    {
      "id": 204,
      "name": "The Maze Runner",
      "author": "James Dashner",
      "category": "youngAdult",
      "image_url": "https://example.com/ya1.jpg",
      "year_published": 2009,
      "pages": 384,
      "description": "A dystopian young adult novel about a group of teenagers trying to escape a mysterious maze."
    },
    {
      "id": 205,
      "name": "Introduction to Quantum Mechanics",
      "author": "David J. Griffiths",
      "category": "Educational",
      "image_url": "https://example.com/educational1.jpg",
      "year_published": 1995,
      "pages": 480,
      "description": "A textbook on the fundamental principles of quantum mechanics for students."
    }
  ]
  