import React from 'react';
import "./App.css"
import CategoryList from './components/CategoryList';
import PopularBooks from './components/PopularBooks';
import Header from './components/Header';
import Error from './components/Error';
import BookList from './components/BookList';
import { Outlet } from 'react-router-dom';
//app component
function App(){
  return(<>
  <h1> Welcome to Book Haven</h1>
    <Header/>
    <Outlet/>
  </>)
}
export default App;
