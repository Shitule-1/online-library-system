export const Data=[
    {
      "id": 201,
      "name": "The Lost Kingdom",
      "author": "Amy White",
      "category": "fiction",
      "image_url":"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRzwgSvmi2xjA-0_-p_bRWF2wenBAyaW9_AQQ&s",
      "year_published": 2021,
      "pages": 350,
      "description": "A fantasy novel set in a forgotten world of magic and intrigue."
    },
    {
      "id": 202,
      "name": "The Power of Habit",
      "author": "Charles Duhigg",
      "category": "nonFiction",
      "image_url":"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRzwgSvmi2xjA-0_-p_bRWF2wenBAyaW9_AQQ&s",
      "year_published": 2012,
      "pages": 370,
      "description": "An insightful exploration of the science behind habit formation."
    },
    {
      "id": 203,
      "name": "The Adventures of Sammy the Squirrel",
      "author": "Linda Green",
      "category": "childrensBbooks",
      "image_url":"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRzwgSvmi2xjA-0_-p_bRWF2wenBAyaW9_AQQ&s",
      "year_published": 2019,
      "pages": 50,
      "description": "A fun and adventurous story about a squirrel discovering the forest."
    },
    {
      "id": 204,
      "name": "The Maze Runner",
      "author": "James Dashner",
      "category": "youngAdult",
      "image_url":"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRzwgSvmi2xjA-0_-p_bRWF2wenBAyaW9_AQQ&s",
      "year_published": 2009,
      "pages": 384,
      "description": "A dystopian young adult novel about a group of teenagers trying to escape a mysterious maze."
    },
    {
      "id": 205,
      "name": "Introduction to Quantum Mechanics",
      "author": "David J. Griffiths",
      "category": "Educational",
      "image_url":"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRzwgSvmi2xjA-0_-p_bRWF2wenBAyaW9_AQQ&s",
      "year_published": 1995,
      "pages": 480,
      "description": "A textbook on the fundamental principles of quantum mechanics for students."
    },
    
      {
          "id": 206,
          "name": "Sapiens: A Brief History of Humankind",
          "author": "Yuval Noah Harari",
          "category": "nonFiction",
          "image_url":"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRzwgSvmi2xjA-0_-p_bRWF2wenBAyaW9_AQQ&s",
          "year_published": 2011,
          "pages": 443,
          "description": "A narrative of humanity’s creation and evolution."
      },
      {
          "id": 207,
          "name": "The Great Gatsby",
          "author": "F. Scott Fitzgerald",
        "category": "fiction",
        "image_url":"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRzwgSvmi2xjA-0_-p_bRWF2wenBAyaW9_AQQ&s",
        "year_published": 1925,
          "pages": 180,
          "description": "A critique of the American Dream set in the Roaring Twenties."
      },
      {
          "id": 208,
          "name": "Charlotte's Web",
          "author": "E.B. White",
          "category": "childrensBbooks",
          "image_url":"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRzwgSvmi2xjA-0_-p_bRWF2wenBAyaW9_AQQ&s",
          "year_published": 1952,
          "pages": 192,
          "description": "A touching story about friendship between a pig named Wilbur and a spider named Charlotte."
      },
      {
          "id": 209,
          "name": "The Hunger Games",
          "author": "Suzanne Collins",
          "category": "youngAdult",
          "image_url":"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRzwgSvmi2xjA-0_-p_bRWF2wenBAyaW9_AQQ&s",
          "year_published": 2008,
          "pages": 374,
          "description": "A dystopian novel where children are selected to fight to the death in a televised event."
      },
      {
          "id": 210,
          "name": "The Power of Habit",
          "author": "Charles Duhigg",
          "category": "Educational",
          "image_url":"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRzwgSvmi2xjA-0_-p_bRWF2wenBAyaW9_AQQ&s",
          "year_published": 2012,
          "pages": 370,
          "description": "An insightful exploration of the science behind habit formation."
      },
      {
          "id": 211,
          "name": "The Midnight Library",
          "author": "Matt Haig",
          "category": "fiction",
          "image_url":"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRzwgSvmi2xjA-0_-p_bRWF2wenBAyaW9_AQQ&s",
          "year_published": 2020,
          "pages": 304,
          "description": "A novel about a woman who discovers a library with infinite books that allow her to explore the different paths her life could have taken."
      },
      {
          "id": 212,
          "name": "Educated",
          "author": "Tara Westover",
          "category": "nonFiction",
          "image_url":"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRzwgSvmi2xjA-0_-p_bRWF2wenBAyaW9_AQQ&s",
          "year_published": 2018,
          "pages": 334,
          "description": "A memoir about a woman who grows up in a strict and abusive household in rural Idaho but eventually escapes to learn about the wider world through education."
      },
      {
          "id": 213,
          "name": "Harry Potter and the Sorcerer's Stone",
          "author": "J.K. Rowling",
          "category": "childrensBbooks",
          "image_url":"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRzwgSvmi2xjA-0_-p_bRWF2wenBAyaW9_AQQ&s",
          "year_published": 1997,
          "pages": 309,
          "description": "The first book in a series about a young wizard's adventures at Hogwarts School of Witchcraft and Wizardry."
      },
      {
          "id": 214,
          "name": "To All the Boys I've Loved Before",
          "author": "Jenny Han",
          "category": "youngAdult",
          "image_url":"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRzwgSvmi2xjA-0_-p_bRWF2wenBAyaW9_AQQ&s",
          "year_published": 2014,
          "pages": 355,
          "description": "A sweet story about a girl's secret love letters that get sent out to her crushes."
      },
      {
          "id": 215,
          "name": "The Body Keeps the Score",
          "author": "Bessel van der Kolk",
          "category": "Educational",
          "image_url":"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRzwgSvmi2xjA-0_-p_bRWF2wenBAyaW9_AQQ&s",
          "year_published": 2014,
          "pages": 464,
          "description": "A groundbreaking book on trauma and its effects on the body and mind."
      },
      {
          "id": 216,
          "name": "Circe",
          "author": "Madeline Miller",
          "category": "fiction",
          "image_url":"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRzwgSvmi2xjA-0_-p_bRWF2wenBAyaW9_AQQ&s",
          "year_published": 2018,
          "pages": 400,
          "description": "A reimagining of the life of Circe, a figure from Greek mythology."
      },
      {
          "id": 217,
          "name": "Born a Crime: Stories from a South African Childhood",
          "author": "Trevor Noah",
          "category": "nonFiction",
          "image_url":"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRzwgSvmi2xjA-0_-p_bRWF2wenBAyaW9_AQQ&s",
          "year_published": 2016,
          "pages": 304,
          "description": "A collection of stories from comedian Trevor Noah's childhood in South Africa."
      },
      {
          "id": 218,
          "name": "Matilda",
          "author": "Roald Dahl",
          "category": "childrensBbooks",
          "image_url":"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRzwgSvmi2xjA-0_-p_bRWF2wenBAyaW9_AQQ&s",
          "year_published": 1988,
          "pages": 240,
          "description": "A story about a gifted girl with a love for books and a clever plan to deal with her unkind family."
      },
      {
          "id": 219,
          "name": "The Fault in Our Stars",
          "author": "John Green",
          "category": "youngAdult",
          "image_url":"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRzwgSvmi2xjA-0_-p_bRWF2wenBAyaW9_AQQ&s",
          "year_published": 2012,
          "pages": 313,
          "description": "A poignant love story between two teenagers with cancer."
      },
      {
          "id": 220,
          "name": "The Elements of Style",
          "author": "William Strunk Jr. and E.B. White",
          "category": "Educational",
          "image_url":"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRzwgSvmi2xjA-0_-p_bRWF2wenBAyaW9_AQQ&s",
          "year_published": 1959,
          "pages": 105,
          "description": "A classic guide to writing well."
      }
    
  ]
  