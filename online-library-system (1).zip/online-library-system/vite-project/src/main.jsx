import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import App from './App.jsx'
import './index.css'
import { createBrowserRouter,RouterProvider } from "react-router-dom";
import BrowseBooks from './components/BrowseBooks.jsx';
import AddBooks from './components/AddBooks.jsx';
 import Error from './components/Error.jsx';
import BookList from './components/BookList.jsx';
import BookDetails from './components/BookDetails.jsx';
import BookInfo from './components/BookInfo.jsx';
import CategoryList from './components/CategoryList.jsx';
import PopularBooks from './components/PopularBooks.jsx';
const appRoute=createBrowserRouter([
  {path:"/",
  element:<App/>,
   children:[
    { path:"/",
      element:(<><CategoryList/> <PopularBooks/></>)
    } ,
    {path:"/BrowseBooks",
      element:<BrowseBooks/>
     },
     {path:"/AddBooks",
      element:<AddBooks/>
     },
     {path:"/books/:category",
      element:<BookList/>
     },
     {path:"/books/:category/:name",
      element:<BookDetails/>
     },
     {path:"/:id",
      element:<BookInfo/>
     },
   ],
  errorElement:<Error/>
   },
   
  
])
createRoot(document.getElementById('root')).render(
  <StrictMode>
    <RouterProvider router={appRoute} />
  </StrictMode>,
)
