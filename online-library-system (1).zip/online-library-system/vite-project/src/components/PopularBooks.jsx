import "../componentsCSS/PopularBooks.css"
import { Link } from "react-router-dom";
function PopularBooks(){
    return(<>
    <div className="PopularBooksDiv">
        <h2>Some Popular Books</h2>
        <ul>
          <li> <Link to="/books/fiction">The Lost Kingdom
          </Link></li>            

          <li>  <Link to="/books/childrensBbooks">The Adventures of Sammy the Squirrel
            </Link></li>
            <li><Link to="/books/youngAdult">The Maze Runner
            </Link> </li>
        </ul>
    </div>
    
    
    </>)
}

export default PopularBooks