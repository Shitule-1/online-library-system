import { Data } from "../utils/MockData"
import { useParams } from "react-router-dom"
function BookDetails(){
    const params = useParams();
    return (<>
        <h1>BookDetails Component</h1>
          
    </>)
}
export default BookDetails

