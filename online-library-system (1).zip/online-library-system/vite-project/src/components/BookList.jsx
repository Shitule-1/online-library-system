import { Data } from "../utils/MockData";
import { useParams } from "react-router-dom";
import { Link } from "react-router-dom";
 import "../componentsCSS/BookList.css"
function BookList() {
    const params = useParams();
    console.log(params);
    
    // Use '===' for comparison instead of '='
    const filteredBooks = Data.filter(book => book.category === params.category);

    return (
        <>   <Link to="/"><button>Back</button></Link>
            <h2>BookList Component</h2>
            {filteredBooks.length > 0 ? (
                <div className="BookListDiv">
                    <ul>
                    {filteredBooks.map((book, index) => (
                        <li key={index}>
                            <h3>{book.name}</h3>
                            <p>Author: {book.author}</p>
                            <p>Category: {book.category}</p>
                            <Link to={`/${book.id}`}><button style={{backgroundColor:"blueviolet"}}>View Detail</button></Link>
                            
                        </li>
                    ))}
                </ul>
                </div>
            ) : (
                <p>No books found in this category.</p>
            )}
            {console.log(filteredBooks)}
        </>
    );
}

export default BookList;

