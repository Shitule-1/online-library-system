import { Link } from "react-router-dom"
function Error(){
    return (<>
    <h1>Page Not Found</h1>
     <h1> <Link to="/Home">Go To Home</Link></h1>
    </>)
}
export default Error