import { Link, useParams } from "react-router-dom"
import { Data } from "../utils/MockData"
import "../componentsCSS/BookInfo.css"
function BookInfo(props) {
    const params = useParams();
    const filteredBooks = Data.filter(book => book.id === Number(params.id)); // Convert params.id to number
    return (
        <>
        <Link to="/BrowseBooks"><button>Back</button></Link>
        &nbsp; {/* for adding space btwn btns */}
        
        <Link to="/"><button>Go to Category Page</button></Link>
        <h1>BookInfo Component</h1>

          <div className="BookInfoDiv">

          <ul>
               {filteredBooks.map((book, index) => (
              <li key={index}>
               
               <img  src={book.image_url}  />
               <h2>Book Name:{book.name}</h2>
                <h3>Book Author:{book.author}</h3>
                <h4>Book Description:{book.description}</h4>
                {console.log(book.image_url)}

              </li>
            ))}
          </ul>f
          </div>
        </>
    );
}

export default BookInfo;
