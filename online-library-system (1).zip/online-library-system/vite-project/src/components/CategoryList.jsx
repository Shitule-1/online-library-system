import { Link } from "react-router-dom"
import "../componentsCSS/CategoryList.css"
function CategoryList(){
    return(<>
       <div className="CategoryListDiv">
           <h2>Categories of Books</h2>
           <ul>
  <li><Link to="/books/fiction">Fiction</Link></li>
  <li><Link to="/books/nonFiction">Non-Fiction</Link></li>
  <li><Link to="/books/childrensBbooks">Children's Books</Link></li>
  <li><Link to="/books/youngAdult">Young Adult (YA)</Link></li>
  <li><Link to="/books/Educational">Educational</Link></li>
</ul>
       </div>
    </>)
}
export default CategoryList