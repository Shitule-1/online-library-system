import "../componentsCSS/Header.css"
import { Link } from "react-router-dom";

function Header(){
    return(<>
        
        <ul className="HederUlList">
        <li><Link to="/">  Home</Link></li>  
        <li> <Link to="/BrowseBooks"> Browser Books</Link> </li>
            <li><Link to="/AddBooks">Add Books</Link></li>
        </ul>
    </>)
}
export default Header