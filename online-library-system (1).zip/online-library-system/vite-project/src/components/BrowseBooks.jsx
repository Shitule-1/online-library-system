import { Data } from "../utils/MockData";
import { Link } from "react-router-dom";
import { useState } from "react";
import "../componentsCSS/BrowseBooks.css"
function BrowseBooks() {
  const [searchTerm, setSearchTerm] = useState('');

  function searchBook(e) {
    setSearchTerm(e.target.value); // Update search term as user types
  }

  // Filter the books based on the search term
  const filteredBooks = Data.filter(book =>
    book.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="BrowseBooksDiv">
      <h1>BrowserBooks Component</h1>
      {/* Attach the searchBook function to the input field's onChange */}
      <input 
        type="text" 
        placeholder="Search book By Book Name" 
        value={searchTerm}
        onChange={searchBook} 
      />
      <button>Search</button> {/* Button can trigger further actions if needed */}
      
      <ul>
        {filteredBooks.map((book) => (
          <li key={book.id}>
            <div className="BrowserBookStyle">  
              <h3> Book Name:{book.name}</h3>
              
            <Link to={`/${book.id}`}><button style={{backgroundColor:"blueviolet"}}>View Detail</button></Link>
             </div>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default BrowseBooks;
